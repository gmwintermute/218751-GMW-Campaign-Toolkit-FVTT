# Foundry Virtual Tabletop - API Documentation Context

This directory contains a local, offline copy of the **Foundry Virtual Tabletop (Foundry VTT) API Documentation for Version 14**. It is intended to serve as a comprehensive reference for developers building modules, systems, or other integrations for the Foundry VTT platform.

## Directory Overview

The project is structured as a static website generated from the Foundry VTT source code, providing detailed information about the JavaScript API.

- **Purpose:** Provide instructional context and reference material for Foundry VTT API development.
- **Version:** 14
- **Main Technologies:** HTML, CSS, JavaScript (static documentation site).

## Key Files and Directories

- **`api/index.html`**: The entry point for the documentation. It contains high-level overviews of the Public vs. Private API, Documents and Data models, the Game Canvas, User Interface components, and more.
- **`api/classes/`**: Detailed documentation for every class in the Foundry VTT API (e.g., `Actor`, `Item`, `Scene`, `ApplicationV2`).
- **`api/modules/`**: Organizes the API into functional groups like `foundry.applications`, `foundry.documents`, etc.
- **`api/interfaces/`, `api/types/`, `api/enums/`**: Definitions for data structures, types, and enumerations used throughout the API.
- **`api/hierarchy.html`**: A visual representation of the class inheritance hierarchy.
- **`api/assets/`**: Contains the CSS and JS files required to render the documentation site.

## Usage Guidelines

This directory is primarily used for **Inquiry** tasks. When asked about Foundry VTT API features, classes, or patterns:

1.  **Search the Documentation**: Use `grep_search` on the `api` directory or specific subdirectories like `api/classes` to find relevant methods or properties.
2.  **Read the Overviews**: Reference `api/index.html` for architectural patterns (e.g., how the `DataModel` or `Document` abstraction works).
3.  **Verify Versioning**: Ensure that the information provided matches the Version 14 API documented here.

### Common Search Patterns

- To find a class definition: `grep_search pattern="class <ClassName>"` in `api/classes/`.
- To find a method: `grep_search pattern="<methodName>"` across the `api` directory.
- To understand a module: Read the corresponding file in `api/modules/`.

## Custom Commands

- **"gitupdate"**: When this command is issued, perform the following sequence:
    1.  Increment the **PATCH** version in `module.json`.
    2.  Update `RELEASE-NOTES.md` with a summary of the latest changes.
    3.  Stage all changes (`git add .`).
    4.  Commit the changes with a descriptive message including the new version number.
    5.  Push the changes to the remote repository.
